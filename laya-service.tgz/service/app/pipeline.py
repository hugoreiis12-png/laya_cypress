"""One document end to end: vision evidence -> deterministic fields -> decision -> contract."""
import logging
import time
from dataclasses import asdict, replace
from typing import Any, Callable, Protocol

from . import audit, cnpj_key, comprovante, contract, items, key_reading, rules, signature_decision
from .config import SIGNATURE_ENGINE_JUDGE, SIGNATURE_ENGINE_TWO_VOTES, TYPE_ENGINE_RULES, Settings
from .hermes_client import HermesError
from .judge_capacity import JudgeCapacity
from .laya_client import LayaError, TypeDecision, state_for
from .signature_decision import INVALID_IMAGE, SIGNED, UNCERTAIN, UNSIGNED, SignatureVerdict
from .signature_model import SignatureDecision, SignatureModelError
from .vision.analyze import Evidence
from .vision.image_io import ImageError
from .vision_judge import JudgeError, SignatureOpinion

log = logging.getLogger(__name__)
CONTRACT_VERSION = "v3"
MS_PER_SECOND = 1000
MIN_OCR_CHARS = 40  # shorter OCR text means the photo was not read; the judge transcribes it
MIN_REVIEW_SECONDS = 1.0  # less time than this cannot produce an answer from the judge


class Classifier(Protocol):
    def classify(self, ocr_text: str, extracted: dict[str, Any]) -> TypeDecision: ...


class SignatureModel(Protocol):
    def decide(self, state: dict[str, Any]) -> SignatureDecision: ...


class SignatureShadow(Protocol):
    def observe(self, data: bytes, rotation: int) -> dict[str, Any]: ...


class Judge(Protocol):
    def transcribe(self, data: bytes) -> str: ...

    def read_access_key(self, data: bytes, timeout: float) -> str: ...

    def assess_signature(self, data: bytes, timeout: float) -> SignatureOpinion: ...


class Auditor(Protocol):
    def audit(self, answer: dict[str, Any], ocr_text: str, timeout: float) -> dict[str, Any]: ...


def extract_fields(evidence: Evidence, whitelist: tuple[str, ...]) -> dict[str, Any]:
    """Deterministic fields shared by serving and training, so both see the same signals."""
    text = evidence.text
    found = (evidence.access_key, *evidence.other_keys, *cnpj_key.find_access_keys(text))
    keys = list(dict.fromkeys(key for key in found if key))
    key = keys[0] if keys else ""
    return {
        "chave": key,
        "chaves": keys,
        "cnpj": cnpj_key.pick_issuer(text, whitelist, key),
        "numero": cnpj_key.invoice_number(text, key),
        "comprovante": comprovante.extract(text),
        "itens": items.extract(text),
    }


def laya_signals(fields: dict[str, Any]) -> dict[str, bool]:
    return {"chave_valida": bool(fields["chave"]), "cnpj_na_whitelist": bool(fields["cnpj"])}


class Pipeline:
    def __init__(self, settings: Settings, analyze: Callable[[bytes], Evidence], laya: Classifier,
                 signature_model: SignatureModel | None = None, shadow: SignatureShadow | None = None,
                 hermes: Classifier | None = None, judge: Judge | None = None,
                 judge_capacity: JudgeCapacity | None = None, auditor: Auditor | None = None) -> None:
        self._settings, self._analyze, self._laya = settings, analyze, laya
        self._signature_model, self._shadow = signature_model, shadow
        self._hermes, self._judge, self._judge_capacity, self._auditor = hermes, judge, judge_capacity, auditor
        self._two_votes = settings.signature_engine == SIGNATURE_ENGINE_TWO_VOTES
        self._judge_alone = settings.signature_engine == SIGNATURE_ENGINE_JUDGE

    def run(self, data: bytes, context: dict[str, Any]) -> dict[str, Any]:
        started = time.monotonic()
        meta: dict[str, Any] = {"contrato": CONTRACT_VERSION, "id": context.get("id"), "tentativas": []}
        try:
            evidence = self._analyze(data)
        except ImageError as exc:
            meta["tentativas"].append({"motor": "visao", "erro": str(exc)})
            meta["estado_assinatura"] = INVALID_IMAGE
            meta["inconclusivo"] = True
            return contract.envelope(contract.build("imagem_invalida"), self._finish(meta, started))
        fields = self._extract(evidence)
        doc_type, confidence = self._decide(evidence, fields, meta)
        reason = self._judge_reason(evidence, fields, doc_type, confidence)
        judged = self._consult_judge(data, evidence, reason, meta) if reason else None
        if judged is not None:
            evidence, fields, doc_type, confidence = judged
        read_fields = self._read_key(data, evidence, fields, doc_type, meta, started)
        if read_fields is not None:
            fields, doc_type, confidence = read_fields, "canhoto", None
        doc_type = self._settle_type(doc_type, confidence, fields, meta)
        decided = self._signature(doc_type, evidence, fields, meta, data, started)
        if decided is not None and self._shadow is not None and not self._two_votes:
            self._observe_shadow(data, evidence.rotation, decided["possui_assinatura"], meta)
        built = contract.build(doc_type, decided, fields)
        self._audit(doc_type, built, fields, evidence, meta, started)
        meta["leitura"] = audit.reading(evidence.text, evidence.access_key, fields)
        meta["inconclusivo"] = self._inconclusive(doc_type, meta)
        return contract.envelope(built, self._finish(meta, started, evidence))

    def _audit(self, doc_type: str, built: dict[str, Any], fields: dict[str, Any], evidence: Evidence,
               meta: dict[str, Any], started: float) -> None:
        """Deterministic checks can send a case to the reserve; Hermes is only recorded until it is measured."""
        meta["auditoria"] = {"problemas": audit.problems(doc_type, fields)}
        remaining = self._settings.review_deadline - (time.monotonic() - started)
        if self._auditor is None or not evidence.text.strip() or remaining < MIN_REVIEW_SECONDS:
            return
        try:
            meta["auditoria"]["hermes"] = self._auditor.audit(built, evidence.text, remaining)
        except HermesError as exc:
            log.warning("auditoria do hermes indisponível: %s", exc)
            meta["auditoria"]["hermes"] = {"erro": "indisponivel"}

    def _inconclusive(self, doc_type: str, meta: dict[str, Any]) -> bool:
        if doc_type not in self._settings.conclusive_types or meta["auditoria"]["problemas"]:
            return True
        return doc_type == "canhoto" and meta.get("estado_assinatura") not in (SIGNED, UNSIGNED)

    def _extract(self, evidence: Evidence) -> dict[str, Any]:
        return extract_fields(evidence, self._settings.whitelist_cnpj)

    def _decide(self, evidence: Evidence, fields: dict[str, Any], meta: dict[str, Any]) -> tuple[str, float | None]:
        """A valid access key is proof of a fiscal document, so it overrides any classifier."""
        doc_type, confidence = self._classify(evidence, fields, meta)
        if fields["chave"] and doc_type != "canhoto":
            meta["veto_tipo"] = {"de": doc_type, "motivo": "chave_valida"}
            return "canhoto", None
        return doc_type, confidence

    def _settle_type(self, doc_type: str, confidence: float | None, fields: dict[str, Any],
                     meta: dict[str, Any]) -> str:
        """A type below the threshold is not an answer: the flow asks for a new photo and the case is queued."""
        undecided = confidence is not None and confidence < self._settings.judge_threshold
        if not undecided or doc_type == "imagem_invalida" or fields["chave"]:
            return doc_type
        meta["tipo_em_duvida"] = {"sugerido": doc_type, "confianca": confidence}
        return "imagem_invalida"

    def _enter_judge(self, meta: dict[str, Any]) -> bool:
        if self._judge_capacity is None:
            return True
        refusal = self._judge_capacity.enter()
        meta["capacidade_juiz"] = refusal or "ok"
        return refusal is None

    def _leave_judge(self) -> None:
        if self._judge_capacity is not None:
            self._judge_capacity.leave()

    def _observe_laya(self, evidence: Evidence, fields: dict[str, Any], meta: dict[str, Any]) -> None:
        """Laya answers for the record only; its failure never touches the decision."""
        try:
            decision = self._laya.classify(evidence.text, laya_signals(fields))
        except LayaError as exc:
            log.warning("laya observado indisponível: %s", exc)
            meta["laya_observado"] = {"erro": "indisponivel"}
            return
        meta["laya_observado"] = {"tipo": decision.doc_type, "confianca": decision.confidence}

    def _by_rules(self, evidence: Evidence, fields: dict[str, Any], meta: dict[str, Any]) -> tuple[str, None]:
        meta["motor_decisao"] = "regras"
        meta.pop("confianca_tipo", None)
        return rules.classify(evidence.text, fields["chave"], fields["comprovante"], fields["itens"]), None

    def _classify(self, evidence: Evidence, fields: dict[str, Any], meta: dict[str, Any]) -> tuple[str, float | None]:
        """Rules when configured; otherwise Laya, then Hermes as the fallback consultant, then the rules."""
        if self._settings.type_engine == TYPE_ENGINE_RULES:
            self._observe_laya(evidence, fields, meta)
            return self._by_rules(evidence, fields, meta)
        for name, engine, errors in (("laya", self._laya, LayaError), ("hermes", self._hermes, HermesError)):
            if engine is None:
                continue
            try:
                decision = engine.classify(evidence.text, laya_signals(fields))
            except errors as exc:
                log.warning("%s indisponível: %s", name, exc)
                meta["tentativas"].append({"motor": name, "erro": str(exc)})
                continue
            meta.update(motor_decisao=name, probabilidades=decision.probabilities, confidences=decision.confidences,
                        truncado=decision.truncated, confianca_tipo=decision.confidence)
            return decision.doc_type, decision.confidence
        return self._by_rules(evidence, fields, meta)

    def _judge_reason(self, evidence: Evidence, fields: dict[str, Any], doc_type: str,
                      confidence: float | None) -> str | None:
        if self._judge is None or not self._settings.judge_transcribe:
            return None
        if len(evidence.text.strip()) < MIN_OCR_CHARS:
            return "ocr_curto"
        if doc_type == "imagem_invalida":
            return "reavaliar_invalida"
        if confidence is not None and confidence < self._settings.judge_threshold:
            return "baixa_confianca"
        if doc_type == "pedido" and not fields["itens"]:
            return "pedido_sem_itens"
        if doc_type == "comprovante" and not (fields["comprovante"] or {}).get("valor"):
            return "comprovante_sem_valor"
        return None

    def _consult_judge(self, data: bytes, evidence: Evidence, reason: str,
                       meta: dict[str, Any]) -> tuple[Evidence, dict[str, Any], str, float | None] | None:
        """The judge only reads; Laya decides again, with its reading first because the encoder cuts from the end."""
        if not self._enter_judge(meta):
            return None
        try:
            transcript = self._judge.transcribe(data)
        except JudgeError as exc:
            log.warning("juiz indisponível: %s", exc)
            meta["tentativas"].append({"motor": "juiz", "erro": str(exc)})
            return None
        finally:
            self._leave_judge()
        meta["juiz"] = {"motivo": reason, "caracteres": len(transcript)}
        judged = replace(evidence, text=f"{evidence.text}\n{transcript}".strip())
        fields = self._extract(judged)
        reading = replace(evidence, text=f"{transcript}\n{evidence.text}".strip())
        doc_type, confidence = self._decide(reading, fields, meta)
        return judged, fields, doc_type, confidence

    def _wants_key(self, evidence: Evidence, fields: dict[str, Any], doc_type: str) -> bool:
        if self._judge is None or not self._settings.judge_read_key or fields["chave"]:
            return False
        return doc_type in ("imagem_invalida", "canhoto") or len(evidence.text.strip()) < MIN_OCR_CHARS

    def _read_key(self, data: bytes, evidence: Evidence, fields: dict[str, Any], doc_type: str,
                  meta: dict[str, Any], started: float) -> dict[str, Any] | None:
        """A valid whitelisted key from the judge proves a canhoto; the original evidence stays for the record."""
        remaining = self._settings.review_deadline - (time.monotonic() - started)
        if not self._wants_key(evidence, fields, doc_type) or remaining < MIN_REVIEW_SECONDS:
            return None
        outcome, key = key_reading.read(self._judge, self._judge_capacity, data,
                                        min(remaining, self._settings.judge_read_timeout), self._settings.whitelist_cnpj)
        meta["leitura_juiz"] = outcome
        return self._extract(replace(evidence, access_key=key)) if key else None

    def _signature(self, doc_type: str, evidence: Evidence, fields: dict[str, Any], meta: dict[str, Any],
                   data: bytes, started: float) -> dict[str, Any] | None:
        if doc_type == "imagem_invalida":
            meta["estado_assinatura"] = UNCERTAIN if "tipo_em_duvida" in meta else INVALID_IMAGE
        if doc_type != "canhoto":
            return None
        if self._judge_alone:
            verdict = self._judge_verdict(data, started, meta)
        elif self._two_votes:
            verdict = self._vote(data, evidence, started, meta)
        else:
            verdict = self._current_verdict(data, evidence, fields, started, meta)
        meta["estado_assinatura"] = verdict.state
        return contract.signature(verdict.signed, verdict.confidence, "manuscrita")

    def _current_verdict(self, data: bytes, evidence: Evidence, fields: dict[str, Any], started: float,
                         meta: dict[str, Any]) -> SignatureVerdict:
        verdict = self._model_signature(evidence, fields, meta)
        if verdict is None:
            verdict = signature_decision.from_ink(evidence.ink, self._settings)
            meta["assinatura"] = {"motor": "regras", "calibrado": False, "atributos": asdict(evidence.ink)}
        return self._review_signature(data, verdict, started, meta) if verdict.state == UNCERTAIN else verdict

    def _vote(self, data: bytes, evidence: Evidence, started: float, meta: dict[str, Any]) -> SignatureVerdict:
        """The judge is asked only when the detector sees a signature, so its load stays on what could be released."""
        detector = self._detector_vote(data, evidence.rotation, meta)
        opinion = self._ask_signature(data, started, meta) if detector is True else None
        verdict = signature_decision.from_votes(detector, opinion, self._settings.judge_min_vote_confidence)
        meta["votos"] = {"detector": detector, "juiz": opinion.signed if opinion else None,
                         "confianca_juiz": opinion.confidence if opinion else None}
        return verdict

    def _judge_verdict(self, data: bytes, started: float, meta: dict[str, Any]) -> SignatureVerdict:
        opinion = self._ask_signature(data, started, meta)
        meta["votos"] = {"detector": None, "juiz": opinion.signed if opinion else None,
                         "confianca_juiz": opinion.confidence if opinion else None}
        return signature_decision.from_judge_alone(opinion, self._settings.judge_min_vote_confidence)

    def _detector_vote(self, data: bytes, rotation: int, meta: dict[str, Any]) -> bool | None:
        if self._shadow is None:
            return None
        observed = self._shadow.observe(data, rotation)
        meta["sombra_assinatura"] = observed
        return observed.get("liberaria")

    def _ask_signature(self, data: bytes, started: float, meta: dict[str, Any]) -> SignatureOpinion | None:
        """One judge attempt inside the deadline and the capacity; the reason for any refusal stays on record."""
        if self._judge is None:
            return None
        remaining = self._settings.review_deadline - (time.monotonic() - started)
        if remaining < MIN_REVIEW_SECONDS:
            meta["revisao_assinatura"] = {"motor": "juiz", "resultado": "sem_prazo"}
            return None
        if not self._enter_judge(meta):
            meta["revisao_assinatura"] = {"motor": "juiz", "resultado": "sem_capacidade"}
            return None
        try:
            return self._judge.assess_signature(data, remaining)
        except JudgeError as exc:
            log.warning("juiz indisponível na revisão: %s", exc)
            meta["tentativas"].append({"motor": "juiz_assinatura", "erro": str(exc)})
            meta["revisao_assinatura"] = {"motor": "juiz", "resultado": "falha"}
            return None
        finally:
            self._leave_judge()

    def _review_signature(self, data: bytes, verdict: SignatureVerdict, started: float,
                          meta: dict[str, Any]) -> SignatureVerdict:
        opinion = self._ask_signature(data, started, meta)
        if opinion is None:
            return verdict
        reviewed = signature_decision.from_judge(opinion, self._settings.judge_signature_max_confidence)
        meta["revisao_assinatura"] = {"motor": "juiz", "resultado": reviewed.state}
        return reviewed

    def _model_signature(self, evidence: Evidence, fields: dict[str, Any],
                         meta: dict[str, Any]) -> SignatureVerdict | None:
        if self._signature_model is None or not evidence.text.strip():
            return None  # empty OCR never reached the model in training either
        try:
            decision = self._signature_model.decide(state_for(evidence.text, laya_signals(fields), evidence.ink))
        except SignatureModelError as exc:
            log.warning("modelo de assinatura indisponível, usando regras: %s", exc)
            meta["tentativas"].append({"motor": "modelo_assinatura", "erro": str(exc)})
            return None
        meta["assinatura"] = {"motor": "modelo", "calibrado": True, "acao": decision.action,
                              "p_assinado": round(decision.probability_signed, 4)}
        return signature_decision.from_model(decision)

    def _observe_shadow(self, data: bytes, rotation: int, signed: bool, meta: dict[str, Any]) -> None:
        observed = self._shadow.observe(data, rotation)
        if "liberaria" in observed:
            observed["concorda"] = observed["liberaria"] == signed
        meta["sombra_assinatura"] = observed

    def _finish(self, meta: dict[str, Any], started: float, evidence: Evidence | None = None) -> dict[str, Any]:
        meta["latencia_ms"] = int((time.monotonic() - started) * MS_PER_SECOND)
        if evidence:
            meta["rotacao"] = evidence.rotation
        return meta
